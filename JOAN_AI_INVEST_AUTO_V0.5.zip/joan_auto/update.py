#!/usr/bin/env python3
"""Daily official TAIEX closes, conservative confirmed MA alerts. Stdlib only."""
import datetime as dt, json, pathlib, time, urllib.request
ROOT=pathlib.Path(__file__).parent
OUT=ROOT/'data'/'taiex.json'
TZ=dt.timezone(dt.timedelta(hours=8))
now=dt.datetime.now(TZ)
old=json.loads(OUT.read_text()) if OUT.exists() else {'rows':[], 'events':[]}
bydate={r['date']:r for r in old.get('rows',[])}
# Bootstrap 16 months to make MA240 meaningful; thereafter refresh recent 2 months.
months=16 if len(bydate)<240 else 2
for k in reversed(range(months)):
    year=now.year; month=now.month-k
    year+=(month-1)//12; month=(month-1)%12+1
    url=f'https://www.twse.com.tw/rwd/zh/afterTrading/FMTQIK?date={year}{month:02d}01&response=json'
    try:
        req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (compatible; JOAN-AI-INVEST/0.5)','Accept':'application/json'})
        with urllib.request.urlopen(req,timeout=25) as f: payload=json.load(f)
        for rec in payload.get('data',[]):
            try:
                yy,mm,dd=map(int,rec[0].split('/'))
                day=f'{yy+1911:04d}-{mm:02d}-{dd:02d}'
                num=lambda x:float(str(x).replace(',','').replace('+',''))
                close=num(rec[4]); change=num(rec[5]); shares=num(rec[1]); amount=num(rec[2]);
                if close>0 and shares>=0: bydate[day]={'date':day,'close':close,'change':change,'shares':shares,'amount_twd':amount}
            except (ValueError,IndexError,TypeError): continue
    except Exception as e: print('FETCH FAILED',year,month,repr(e))
    time.sleep(.4)
rows=sorted(bydate.values(),key=lambda r:r['date'])
if not rows: raise SystemExit('No official data: refusing to publish simulated data')
# Alert events are confirmed from close, not intraday. Only emit when new trading day observed.
def ma(i,n):return sum(x['close'] for x in rows[i-n+1:i+1])/n if i>=n-1 else None
prior_events={e['key']:e for e in old.get('events',[])}
old_latest=max((r['date'] for r in old.get('rows',[])),default='')
for i,r in enumerate(rows):
    if r['date']<=old_latest:continue
    for n in (20,60,240):
        if i<n+1:continue
        p,pp,c=ma(i-1,n),ma(i-2,n),ma(i,n)
        oldclose=rows[i-1]['close']; close=r['close']
        types=[]
        if oldclose<=p and close>c:types.append('站上')
        if oldclose>=p and close<c:types.append('跌破')
        before=p-pp; after=c-p
        if before<=0 and after>0:types.append('轉上揚')
        if before>=0 and after<0:types.append('轉下彎')
        for t in types:
            key=f"TAIEX:{r['date']}:MA{n}:{t}"
            prior_events[key]={'key':key,'date':r['date'],'symbol':'TAIEX','ma':n,'type':t,'close':round(close,2),'ma_value':round(c,2)}
result={'source':'TWSE FMTQIK','updated_at':now.isoformat(),'latest_trading_date':rows[-1]['date'],'rows':rows,'events':sorted(prior_events.values(),key=lambda e:e['key'])}
OUT.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print('rows',len(rows),'latest',rows[-1]['date'],'events',len(prior_events))
